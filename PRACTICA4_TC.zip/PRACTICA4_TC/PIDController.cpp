// PIDController.cpp
#include "PIDController.h"  

// Recibe los parámetros de sintonía Kp, Ki, Kd, el intervalo de muestreo dt y el factor de filtro N.
// Inicializa los atributos con los valores recibidos, resetea el estado interno y calcula coeficientes iniciales.
PIDController::PIDController(float Kp_, float Ki_, float Kd_, float dt_, uint16_t N_)
  : Kp(Kp_),      // Asigna el valor de ganancia proporcional
    Ki(Ki_),      // Asigna el valor de ganancia integral
    Kd(Kd_),      // Asigna el valor de ganancia derivativa
    dt(dt_),      // Asigna el intervalo de muestreo (en segundos)
    N(N_)         // Asigna el factor de atenuación del filtro derivativo
{
  reset();               // Limpia historiales de error, filtros e inicializa la salida
  computeCoefficients(); // Calcula los coeficientes para PI y derivada con filtro
}

// Método para actualizar los parámetros de sintonía (Kp, Ki, Kd) durante la ejecución.
// Una vez asignados los nuevos valores, recalcula los coeficientes dependientes.
void PIDController::setTunings(float Kp_, float Ki_, float Kd_) {
  Kp = Kp_; Ki = Ki_; Kd = Kd_; // Actualiza las ganancias internas
  computeCoefficients();        // Vuelve a calcular todos los coeficientes con los nuevos valores
}

// Método para modificar el factor de filtro derivativo N.
// Cambiar N implica volver a calcular las constantes del filtro.
void PIDController::setFilter(uint16_t N_) {
  N = N_;                 // Actualiza el factor de filtro
  computeCoefficients();  // Recalcula coeficientes que dependen de N
}

// Reinicia el estado interno del controlador: limpia historial de errores, filtros y asigna valor inicial de salida.
// El parámetro `initialOutput` suele ser el valor inicial del actuador (u0).
void PIDController::reset(float initialOutput) {
  // Borra el historial de error (e[0] = error actual, e[1] = error anterior, e[2] = error de dos pasos atrás)
  e[0] = e[1] = e[2] = 0.0f;
  // Borra el historial de derivada cruda (sin filtrar)
  d[0] = d[1] = 0.0f;
  // Borra el historial de derivada filtrada
  fd[0] = fd[1] = 0.0f;
  // Asigna la salida inicial (valor del actuador) que se acumulará incrementalmente
  out = initialOutput;
}

// Calcula los coeficientes utilizados en la forma incremental del PI y en el término derivativo con filtro.
// Se invoca tras cualquier cambio en Kp, Ki, Kd, dt o N.
void PIDController::computeCoefficients() {
  // ======== PARTE PI (forma incremental) ========
  // Coeficiente A0 para el término proporcional e integral combinado:
  // A0 = Ki * dt + Kp 
  A0 = Ki * dt + Kp;
  // Coeficiente A1 para el término proporcional negativo (utilizado para e(k-1)):
  // A1 = -Kp
  A1 = -Kp;
  // A2 no se usa en un PI incremental simple (solo requiere e(k) y e(k-1)), así que se fija a 0.
  A2 = 0;

  // ======== PARTE DERIVATIVA (forma en diferencias simples) ========
  // Coeficientes que aproximan la derivada: A0d, A1d, A2d
  // Basados en: Kd * (e[k] − 2 e[k−1] + e[k−2]) / dt
  A0d =  Kd / dt;         // Multiplica e[k]
  A1d = -2.0f * Kd / dt;  // Multiplica e[k−1]
  A2d =  Kd / dt;         // Multiplica e[k−2]

  // ======== FILTRO PASA-BAJA PARA DERIVADA ========
  // Se usa la constante de tiempo tau = Kd / (Kp * N)
  float tau = Kd / (Kp * N);
  // Se calcula alpha = dt / (2 · tau)
  float alpha = dt / (2.0f * tau);
  // Coeficientes recursivos para el filtro digital de primer orden:
  // alpha1 = alpha / (alpha + 1)
  alpha1 = alpha / (alpha + 1.0f);
  // alpha2 = (alpha − 1) / (alpha + 1)
  alpha2 = (alpha - 1.0f) / (alpha + 1.0f);
}

// Método principal: calcula la salida del controlador para un nuevo ciclo.
// Debe llamarse cada dt segundos, proporcionando la referencia (setpoint) y la medición actual.
float PIDController::compute(float setpoint, float measured) {
  // ======== GESTIÓN DEL HISTORIAL DE ERRORES ========
  // Desplaza los valores: e[2] <- e[1], e[1] <- e[0]
  e[2] = e[1];
  e[1] = e[0];
  // Calcula el error actual: e[0] = setpoint − measured
  e[0] = setpoint - measured;

  // ======== CÁLCULO INCREMENTAL DEL TÉRMINO PI ========
  // out = out + A0*e[0] + A1*e[1]
  // A0 = Ki*dt + Kp, A1 = −Kp
  out += A0 * e[0] + A1 * e[1];

  // ======== CÁLCULO DE LA DERIVADA (SIN FILTRAR) ========
  // Desplaza el historial crudo: d[1] <- d[0]
  d[1] = d[0];
  // d[0] = A0d*e[0] + A1d*e[1] + A2d*e[2]
  d[0] = A0d * e[0] + A1d * e[1] + A2d * e[2];

  // ======== FILTRADO DE LA DERIVADA ========
  // Desplaza historial de derivada filtrada: fd[1] <- fd[0]
  fd[1] = fd[0];
  // Aplica filtro recursivo: fd[0] = alpha1*(d[0] + d[1]) − alpha2*fd[1]
  fd[0] = alpha1 * (d[0] + d[1]) - alpha2 * fd[1];

  // ======== SUMA DEL TÉRMINO DERIVATIVO FILTRADO ========
  // Se añade la derivada filtrada a la salida acumulada
  out += fd[0];

  // Devuelve la señal de control calculada para este ciclo
  return out;
}
