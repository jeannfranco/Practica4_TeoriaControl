// PIDController.h
#ifndef PIDCONTROLLER_H       
#define PIDCONTROLLER_H      

#include <Arduino.h> 

class PIDController {
public:
  // Constructor: recibe Kp, Ki, Kd (ganancias), dt (intervalo de muestreo en segundos)
  // y N (factor de atenuación del filtro derivativo, por defecto 5).
  PIDController(float Kp, float Ki, float Kd, float dt, uint16_t N = 5);

  // Método para actualizar las ganancias Kp, Ki y Kd en tiempo de ejecución.
  void setTunings(float Kp, float Ki, float Kd);

  // Método para ajustar el factor de filtro derivativo N (mayor N => menos filtrado).
  void setFilter(uint16_t N);

  // Método que calcula la salida de control. Debe llamarse cada dt segundos,
  // pasando el setpoint (referencia) y el valor medido actual.
  float compute(float setpoint, float measured);

  // Reinicia el estado interno: limpia histórico de errores, integrador y filtros.
  // El parámetro initialOutput (por defecto 0) es el valor inicial del actuador.
  void reset(float initialOutput = 0);

private:
  // ======== Parámetros de sintonía ========
  float Kp;       // Ganancia proporcional
  float Ki;       // Ganancia integral
  float Kd;       // Ganancia derivativa
  float dt;       // Intervalo de muestreo (en segundos)

  // ======== Coeficientes para la forma en diferencias ========
  // PI incremental:
  float A0;       // Coeficiente para e[k] en la parte PI
  float A1;       // Coeficiente para e[k−1] (término proporcional negativo)
  float A2;       // Coeficiente adicional (en un PI incremental simple vale 0)

  // Derivada en diferencias:
  float A0d;      // Coeficiente para e[k] en la parte derivativa
  float A1d;      // Coeficiente para e[k−1] en la parte derivativa
  float A2d;      // Coeficiente para e[k−2] en la parte derivativa

  // ======== Coeficientes del filtro pasa-baja (derivada) ========
  float alpha1;   // Coeficiente recursivo para suma de d[k] + d[k−1]
  float alpha2;   // Coeficiente recursivo que multiplica fd[k−1]
  uint16_t N;     // Factor de atenuación (orden del filtro)

  // ======== Historial de errores ========
  // e[0] = error actual (setpoint − medido)
  // e[1] = error en paso anterior
  // e[2] = error en dos pasos atrás
  float e[3];

  // ======== Acumulador de salida (forma incremental PI) ========
  float out;      // Salida acumulada (valor de actuador)

  // ======== Historial de derivada ========
  float d[2];     // d[0] = derivada cruda actual, d[1] = derivada cruda anterior
  float fd[2];    // fd[0] = derivada filtrada actual, fd[1] = filtrada anterior

  // Método interno para recalcular todos los coeficientes si cambian Kp, Ki, Kd, dt o N.
  void computeCoefficients();

}; 

#endif 
